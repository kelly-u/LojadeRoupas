package ifpe.padroes.lojaroupas;

public class MaterialMalha extends MaterialImp {

	@Override
	public void materialRoupaImp() {
		System.out.println("Material malha escolhida!");
		
	}
	
}
