package ifpe.padroes.lojaroupas;

public class GeneroMasculinoImp extends GeneroImp {

	@Override
	public void generoRoupaImp() {
		System.out.println("G�nero masculino escolhido!");
		
	}

}
