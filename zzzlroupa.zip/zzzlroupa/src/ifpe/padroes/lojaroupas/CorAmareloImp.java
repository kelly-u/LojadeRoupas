package ifpe.padroes.lojaroupas;

public class CorAmareloImp extends CorImp {

	@Override
	public void corRoupaImp() {
		System.out.println("Cor amarelo escolhida!");
	}

}
