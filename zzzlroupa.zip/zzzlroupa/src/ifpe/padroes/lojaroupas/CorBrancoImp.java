package ifpe.padroes.lojaroupas;

public class CorBrancoImp extends CorImp {

	@Override
	public void corRoupaImp() {
		System.out.println("Cor branca escolhida!");
	}

}
