package ifpe.padroes.lojaroupas;

public abstract class CorImp {

	public abstract void corRoupaImp();
	
	
}
