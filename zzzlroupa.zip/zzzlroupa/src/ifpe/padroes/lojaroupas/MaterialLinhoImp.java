package ifpe.padroes.lojaroupas;

public class MaterialLinhoImp extends MaterialImp {

	@Override
	public void materialRoupaImp() {
		System.out.println("Material linho escolhido!");
		
	}

}
