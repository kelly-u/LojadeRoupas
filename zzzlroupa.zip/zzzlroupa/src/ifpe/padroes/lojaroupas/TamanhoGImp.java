package ifpe.padroes.lojaroupas;

public class TamanhoGImp extends TamanhoImp {

	@Override
	public void tamanhoRoupaImp() {
		System.out.println("Tamanho G escolhido!");
		
	}

}
