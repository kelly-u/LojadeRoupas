package ifpe.padroes.lojaroupas;

public class TamanhoPImp extends TamanhoImp {

	@Override
	public void tamanhoRoupaImp() {
		System.out.println("Tamanho P escolhido!");
		
	}

}
