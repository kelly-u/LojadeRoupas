package ifpe.padroes.lojaroupas;

public abstract class EstampaImp {

	public abstract void estampaRoupaImp();
	
}
