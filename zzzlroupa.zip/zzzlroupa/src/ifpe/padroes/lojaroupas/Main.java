package ifpe.padroes.lojaroupas;

public class Main {

	public static void main(String[] args) {
		Calca calca = new Calca();
		Saia saia = new Saia();
		Blusa blusa = new Blusa();

/*		CALCA
		//Mundando a cor
		calca.setImpC(new CorAmareloImp());
		//Mostrando a cor
		calca.corRoupa();
		
		//Mundando o material
		calca.setImpM(new MaterialLinhoImp());
		//Mostrando o material
		calca.materialRoupa();
*/	
/* SAIA
		//Mudando o g�nero
		saia.setImpG(new GeneroFemininoImp());
		//Mostrando o g�nero
		saia.generoRoupa();
*/
		//Mundando a cor
		blusa.setImpE(new EstampaLisaImp());
		//Mostrando a cor
		blusa.estampaRoupa();
				
		//Mundando o material
		blusa.setImpT(new TamanhoPImp());
		//Mostrando o material
		blusa.tamanhoRoupa();
		
	}

}
