package ifpe.padroes.lojaroupas;

public abstract class TamanhoImp {

	public abstract void tamanhoRoupaImp();
	
}
