package ifpe.padroes.lojaroupas;

public class GeneroFemininoImp extends GeneroImp {

	@Override
	public void generoRoupaImp() {
		System.out.println("G�nero feminino escolhido!");
		
	}

}
