package ifpe.padroes.lojaroupas;

public class CorAzulImp extends CorImp {

	@Override
	public void corRoupaImp() {
		System.out.println("Cor azul escolhida!");
	}

}
