package ifpe.padroes.lojaroupas;

public class EstampaFlorImp extends EstampaImp {

	@Override
	public void estampaRoupaImp() {
		System.out.println("Estampa flor escolhida!");
		
	}

}
