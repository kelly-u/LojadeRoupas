package ifpe.padroes.lojaroupas;

public class MaterialJeansImp extends MaterialImp {

	@Override
	public void materialRoupaImp() {
		System.out.println("Material jeans escolhido!");
		
	}

}
