package ifpe.padroes.lojaroupas;

public class EstampaBolaImp extends EstampaImp {

	@Override
	public void estampaRoupaImp() {
		System.out.println("Estampa bola escolhida!");
		
	}

}
