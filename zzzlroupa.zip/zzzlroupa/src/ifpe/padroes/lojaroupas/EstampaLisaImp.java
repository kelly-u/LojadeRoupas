package ifpe.padroes.lojaroupas;

public class EstampaLisaImp extends EstampaImp {

	@Override
	public void estampaRoupaImp() {
		System.out.println("Estampa lisa escolhida!");
		
	}

}
