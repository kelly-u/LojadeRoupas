package ifpe.padroes.lojaroupas;

public abstract class GeneroImp {

	public abstract void generoRoupaImp();
	
}
