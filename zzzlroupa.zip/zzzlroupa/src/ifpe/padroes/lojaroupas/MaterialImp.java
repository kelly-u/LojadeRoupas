package ifpe.padroes.lojaroupas;

public abstract class MaterialImp {

	public abstract void materialRoupaImp();
	
}
