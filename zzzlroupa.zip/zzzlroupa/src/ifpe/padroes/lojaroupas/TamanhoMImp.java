package ifpe.padroes.lojaroupas;

public class TamanhoMImp extends TamanhoImp {

	@Override
	public void tamanhoRoupaImp() {
		System.out.println("Tamanho M escolhido!");
		
	}

}
